<?php
    $wide = $_POST["wide"];
    $long = $_POST["long"];
    $result = $wide*$long;

    echo "พื้นที่ของรูปสี่เหลี่ยมที่ความกว้าง $wide หน่วย และ ความยาว $long หน่วย คือ $result หน่วย^2";
?> 